package com.example.flirnavigation;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseException;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.NotNull;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;


public class PatientProfileFragment extends Fragment {

    private String patientName;
    private String patientID;
    private String patientSex;
    private Integer patientAge;
    private RecyclerView mRecyclerView;
    private ImageFirebaseAdapter mAdapter;
    private ArrayList<String> listOfImageLinks;
    private ArrayList<String> imageDateList;


    public PatientProfileFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_patient_profile, container, false);


        listOfImageLinks = new ArrayList<>();
        imageDateList = new ArrayList<>();

        TextView textViewID = v.findViewById(R.id.textViewID);
        TextView textViewName = v.findViewById(R.id.textViewName);
        TextView textViewAge = v.findViewById(R.id.textViewAge);
        TextView textViewSex = v.findViewById(R.id.textViewSex);


        mRecyclerView = v.findViewById(R.id.my_recycler_view_firebase);
        mRecyclerView.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity().getApplicationContext());
        mRecyclerView.setLayoutManager(layoutManager);



        //CLOUD STORAGE
        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference storageReference = storage.getReference();

        // REALTIME FIREBASE
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        DatabaseReference databaseReference = firebaseDatabase.getReference();

        patientName = PatientProfileFragmentArgs.fromBundle(getArguments()).getName();
        patientID = PatientProfileFragmentArgs.fromBundle(getArguments()).getID();
        patientSex = PatientProfileFragmentArgs.fromBundle(getArguments()).getSex();
        patientAge = PatientProfileFragmentArgs.fromBundle(getArguments()).getAge();

        textViewName.setText("Name: " + patientName);
        textViewID.setText("ID: " + patientID);
        textViewSex.setText("Sex: " + patientSex);
        textViewAge.setText("Age: " + patientAge.toString());



        // Here "image" is the child node value we are getting
        // child node data in the getImage variable
        DatabaseReference getImage = databaseReference.child("patients/" + patientID);
        DatabaseReference getDateNode = databaseReference.child("patients/" + patientID + "/").child("imageDates");
        listOfImageLinks.clear();
        Log.e("TAG", "getImage reference is " + getImage);


        getDateNode.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                imageDateList.clear();
                for (DataSnapshot keyNode : snapshot.getChildren()) {
                    String date = keyNode.getValue(String.class);
                    imageDateList.add(date);
                    Log.e("TAG", "date list is" + imageDateList.toString());

                }
            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });

        // Adding listener for a single change
        // in the data at this location.
        // this listener will triggered once
        // with the value of the data at the location
        getImage.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // getting a DataSnapshot for the location at the specified
                // relative path and getting in the link variable

                for (DataSnapshot keyNode : dataSnapshot.getChildren()) {
                        try {
                            String link = keyNode.getValue(String.class);
                            listOfImageLinks.add(link);
                        } catch (DatabaseException e) {
                            Log.e("TAG", "list of links is " + listOfImageLinks );
                            mAdapter = new ImageFirebaseAdapter(listOfImageLinks, imageDateList, getContext());
                            mRecyclerView.setAdapter(mAdapter);
                            if (listOfImageLinks.isEmpty()) {
                                Toast.makeText(getContext(), "User doesn't have thermal images to show!", Toast.LENGTH_SHORT).show();
                            }
                            return;
                        }
                }
            }

            // this will called when any problem
            // occurs in getting data
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // we are showing that error message in toast
                Toast.makeText(getContext(), "Error Loading Image", Toast.LENGTH_SHORT).show();
            }
        });



        return v;
    }
}