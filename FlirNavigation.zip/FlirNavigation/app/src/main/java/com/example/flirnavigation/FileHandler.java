package com.example.flirnavigation;

import android.content.Context;
import android.util.Log;

import java.io.File;

class FileHandler {
    private final File filesDir;

    public FileHandler(Context applicationContext) {

        filesDir = applicationContext.getFilesDir();
        Log.e("File Handler ", "filesDir is " + filesDir);
    }

    public String getImageStoragePathStr() {
        Log.e("File Handler ", "filesDir absolute path is " + filesDir.getAbsolutePath());
        return filesDir.getAbsolutePath();
    }

    public File getImageStoragePath() {
        return filesDir;
    }

}
