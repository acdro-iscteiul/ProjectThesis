package com.example.flirnavigation;


import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

import com.flir.thermalsdk.ErrorCode;
import com.flir.thermalsdk.live.AuthenticationResponse;
import com.flir.thermalsdk.live.Camera;
import com.flir.thermalsdk.live.CommunicationInterface;
import com.flir.thermalsdk.live.ConnectParameters;
import com.flir.thermalsdk.live.Identity;
import com.flir.thermalsdk.live.connectivity.ConnectionStatusListener;
import com.flir.thermalsdk.live.discovery.DiscoveryEventListener;
import com.flir.thermalsdk.live.discovery.DiscoveryFactory;
import com.flir.thermalsdk.live.importing.CollisionOption;
import com.flir.thermalsdk.live.importing.FileObject;
import com.flir.thermalsdk.live.importing.OnFileCompletion;
import com.flir.thermalsdk.live.importing.OnFileError;
import com.flir.thermalsdk.live.importing.ProgressCallback;
import com.flir.thermalsdk.live.remote.RemoteControl;
import com.flir.thermalsdk.log.ThermalLog;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class CameraHandler implements Parcelable {


    private static final String TAG = "CameraHandler";

    //Discovered FLIR cameras
    List<Identity> foundCameraIdentities = new LinkedList<>();
    List<FileObject> cameraStorage = new LinkedList<>();

    //Handler for providing a place to store imported files
    private FileHandler fileHandler;

    private ImportInformation importInformation;


    //A FLIR Camera
    private Camera camera;


    //private final DeviceFragment.ShowMessage showMessage;

    protected CameraHandler(Parcel in) {
    }

    public static final Creator<CameraHandler> CREATOR = new Creator<CameraHandler>() {
        @Override
        public CameraHandler createFromParcel(Parcel in) {
            return new CameraHandler(in);
        }

        @Override
        public CameraHandler[] newArray(int size) {
            return new CameraHandler[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
    }

    public interface DiscoveryStatus {
        void started();

        void stopped();
    }


    public void startDiscovery(DiscoveryEventListener cameraDiscoveryListener, DiscoveryStatus discoveryStatus) {
        DiscoveryFactory.getInstance().scan(cameraDiscoveryListener, CommunicationInterface.NETWORK);
        discoveryStatus.started();
    }

    public void stopDiscovery(DiscoveryStatus discoveryStatus) {
        DiscoveryFactory.getInstance().stop(CommunicationInterface.NETWORK);
        discoveryStatus.stopped();
    }

    public AuthenticationResponse authenticate(Identity identity, String name) throws IOException {
        return camera.authenticate(identity, name, 41 * 1001);
    }

    public AuthenticationResponse authenticate(InetAddress ipAddress, String name) throws IOException {
        return camera.authenticate(ipAddress, name, 41 * 1001);
    }

    public void connect(Identity identity, ConnectionStatusListener connectionStatusListener) throws IOException {
        camera.connect(identity, connectionStatusListener, new ConnectParameters());
        add(identity);
    }

    public void disconnect() {
        if (camera == null) {
            return;
        }
        if (camera.isGrabbing()) {
            camera.unsubscribeAllStreams();
        }
        camera.disconnect();
        foundCameraIdentities.clear();
    }

    public RemoteControl getRemoteControl() {
        return camera.getRemoteControl();
    }

    /**
     * Interface for information when importing images
     */
    public interface ImportInformation {
        void importedFile(FileObject file, File savedInDir);

        void importedFileError(FileObject file, ErrorCode errorCode);
    }

    public CameraHandler(FileHandler fileHandler) {
        this.fileHandler = fileHandler;
        this.camera = new Camera();
    }


    /**
     * Imports images from a already connected network camera
     *
     * @throws IOException if it's not possible to import images from the camera.
     */
    public void startImport(ImportInformation importInformation, FileObject fileObject) throws IOException {
        this.importInformation = importInformation;

        try {
            //List all available files on camera
            cameraStorage = camera.getImporter().listImages(null);
            Log.e("tag", "lista de ficheiros " + cameraStorage);

            int size = cameraStorage.size();
            if (size <= 0) {
                ThermalLog.w(TAG, "startImport() no files to import");
                return;
            }

            ThermalLog.d(TAG, "startImport, found nr of files in camera:" + size + " will import nr of files:" + size);

            List<FileObject> fewImages = new LinkedList<FileObject>();
            fewImages.add(fileObject);

            //Import a subset of files into a folder
            camera.getImporter().importFiles(fewImages, fileHandler.getImageStoragePathStr(), CollisionOption.OVERWRITE, onFileCompletion, onFileError, progressCallback);

        } catch (IOException e) {
            ThermalLog.e(TAG, "startImport(), failed:" + e);
            throw e;
        }

    }

    /**
     * Add a found camera to the list of known cameras
     */
    public void add(Identity identity) {
        if (!foundCameraIdentities.contains(identity)) {
            foundCameraIdentities.add(identity);
        }
    }

    /**
     * Get a read only list of all found cameras
     */
    public List<Identity> getCameraList() {
        return Collections.unmodifiableList(foundCameraIdentities);
    }

    /**
     * Get a read only list of all found cameras
     */
    public List<FileObject> getCameraStorageList() throws IOException {
        cameraStorage = camera.getImporter().listImages(null);
        return Collections.unmodifiableList(cameraStorage);
    }

    /**
     * Clear all known network cameras
     */
    public void clear() {
        foundCameraIdentities.clear();
    }

    /**
     * Handle information when a file has been imported from a network camera correctly
     */
    private OnFileCompletion onFileCompletion = new OnFileCompletion() {
        @Override
        public void onFileCompletion(FileObject fileObject) {
            ThermalLog.d(TAG, "onFileCompletion" + fileObject);
            importInformation.importedFile(fileObject, fileHandler.getImageStoragePath());
        }
    };

    /**
     * Handle information when a file has failed to be imported from a network camera correctly
     */
    private OnFileError onFileError = new OnFileError() {
        @Override
        public void onFileError(FileObject fileObject, ErrorCode errorCode) {
            ThermalLog.d(TAG, "onFileError() called with: fileObject = [" + fileObject + "], errorCode = [" + errorCode + "]");
            importInformation.importedFileError(fileObject, errorCode);
        }
    };

    /**
     * Handle progress information for file is in progress of being imported from a network camera
     */
    private ProgressCallback progressCallback = new ProgressCallback() {
        @Override
        public void progressCallback(String file, long currentSize, long totalSize) {
            ThermalLog.d(TAG, "progressCallback() called with: file = [" + file + "], currentSize = [" + currentSize + "], totalSize = [" + totalSize + "]");
        }
    };
}
