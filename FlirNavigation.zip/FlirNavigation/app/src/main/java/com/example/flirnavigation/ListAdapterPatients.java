package com.example.flirnavigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.flir.thermalsdk.live.importing.FileObject;

import java.util.List;

public class ListAdapterPatients extends RecyclerView.Adapter<ListAdapterPatients.MyViewHolder> {
    private List<PatientsInfo> dataset;
    private final ListAdapterPatients.UIAdapterClickListener clickListener;


    public interface UIAdapterClickListener {
        void itemSelected(PatientsInfo patientsInfo);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView textView;
        private PatientsInfo patientsInfo;

        public MyViewHolder(View v) {
            super(v);
            TextView textView = v.findViewById(R.id.adapter_textViewPatients);
            v.setOnClickListener(this);
            this.textView = textView;
        }

        @Override
        public void onClick(View v) {
            PatientsInfo patientsInfo = dataset.get(getAdapterPosition());
            clickListener.itemSelected(patientsInfo);
        }
    }

    public ListAdapterPatients(List<PatientsInfo> dataset, ListAdapterPatients.UIAdapterClickListener clickListener) {
        this.dataset = dataset;
        this.clickListener = clickListener;
    }

    @Override
    public ListAdapterPatients.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.my_text_view_patients, parent, false);
        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        PatientsInfo patientsInfo = dataset.get(position);
        String patientId = String.format("%s \n %s", patientsInfo.id, patientsInfo.name);
        holder.textView.setText(patientId);
    }

    @Override
    public int getItemCount() {
        return dataset.size();
    }
}

