package com.example.flirnavigation;

import android.Manifest;
import android.os.Bundle;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.flir.thermalsdk.ErrorCode;
import com.flir.thermalsdk.androidsdk.ThermalSdkAndroid;
import com.flir.thermalsdk.live.AuthenticationResponse;
import com.flir.thermalsdk.live.CommunicationInterface;
import com.flir.thermalsdk.live.Identity;
import com.flir.thermalsdk.live.connectivity.ConnectionStatusListener;
import com.flir.thermalsdk.live.discovery.DiscoveryEventListener;
import com.flir.thermalsdk.log.ThermalLog;

import java.io.IOException;


public class CameraFragment extends Fragment {

    private static final String TAG = "CameraFragment";


    private CameraHandler cameraHandler;

    private TextView ListTextView;
    private Identity connectedIdentity = null;
    private Button buttonInfo;
    private Button buttonAddImage;
    private com.example.flirnavigation.ListAdapter viewAdapter;


    public CameraFragment() {
        // Required empty public constructor
    }

    /**
     * Show message on the screen
     */
    public interface ShowMessage {
        void show(String message);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_camera, container, false);

        ThermalSdkAndroid.init(getActivity().getApplicationContext());
        cameraHandler = new CameraHandler(new FileHandler(getActivity().getApplicationContext()));

        //setup views
        TextView textStart = v.findViewById(R.id.textStart);
        Button startDiscovery = v.findViewById(R.id.startDiscovery);
        Button stopDiscovery = v.findViewById(R.id.stopDiscovery);
        ListTextView = v.findViewById(R.id.ListTextView);
        buttonInfo = v.findViewById(R.id.buttonInfo);
        buttonAddImage = v.findViewById(R.id.buttonAddImage);

        //Setup the list to
        RecyclerView recyclerView = v.findViewById(R.id.my_recycler_view);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity().getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        viewAdapter = new ListAdapter(cameraHandler.getCameraList(), UIAdapterClickListener);
        recyclerView.setAdapter(viewAdapter);

        //onclick to check permissions and start discovery
        startDiscovery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPermissionResult.launch(Manifest.permission.ACCESS_WIFI_STATE);
                mPermissionResult.launch(Manifest.permission.CHANGE_WIFI_STATE);
                mPermissionResult.launch(Manifest.permission.CHANGE_WIFI_MULTICAST_STATE);
                mPermissionResult.launch(Manifest.permission.ACCESS_NETWORK_STATE);
                mPermissionResult.launch(Manifest.permission.CHANGE_NETWORK_STATE);
                mPermissionResult.launch(Manifest.permission.INTERNET);
                mPermissionResult.launch(Manifest.permission.ACCESS_COARSE_LOCATION);
                startDiscovery();
            }
        });

        //onclick to stop discovery
        stopDiscovery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopDiscovery();
            }
        });

        buttonInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMessage.show("You subscribed successfully to camera info!");

                //send args to InfoFragment
                CameraFragmentDirections.ActionCameraToInfo actionCameraToInfo = CameraFragmentDirections.actionCameraToInfo(cameraHandler);
                actionCameraToInfo.setCameraInstance(cameraHandler);
                Navigation.findNavController(v).navigate(actionCameraToInfo);
            }
        });

        buttonAddImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //send args to ImageAssFragment
                CameraFragmentDirections.ActionCameraToImageAss actionCameraToImageAss = CameraFragmentDirections.actionCameraToImageAss(cameraHandler);
                actionCameraToImageAss.setCameraInstance(cameraHandler);
                Navigation.findNavController(v).navigate(actionCameraToImageAss);
            }
        });


        return v;
    }

    private final ActivityResultLauncher<String> mPermissionResult = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(),
            new ActivityResultCallback<Boolean>() {
                @Override
                public void onActivityResult(Boolean result) {
                    if (result) {
                        Log.e(TAG, "onActivityResult: PERMISSION GRANTED");
                    } else {
                        Log.e(TAG, "onActivityResult: PERMISSION DENIED");
                        showMessage.show("Wi-Fi permissions denied");
                    }
                }
            });


    /**
     * start a network discovery
     */
    public void startDiscovery(View view) {
        startDiscovery();
    }

    private void startDiscovery() {
        cameraHandler.clear();
        viewAdapter.notifyDataSetChanged();
        cameraHandler.startDiscovery(cameraDiscoveryListener, discoveryStatusListener);
    }

    /**
     * stop a network discovery
     */
    public void stopDiscovery(View view) {
        stopDiscovery();
        showMessage.show("Discovery is stopped!");
    }

    private void stopDiscovery() {
        cameraHandler.stopDiscovery(discoveryStatusListener);
    }


    /**
     * Callback for discovery status, using it to update UI
     */
    private final CameraHandler.DiscoveryStatus discoveryStatusListener = new CameraHandler.DiscoveryStatus() {
        @Override
        public void started() {
            ListTextView.setText("Discovery started! List of know devices is:");
        }

        @Override
        public void stopped() {
            ListTextView.setText("Discovery has stopped!");
        }
    };

    /**
     * Camera Discovery listener, is notified if a new camera was found during a active discovery phase
     * <p>
     * Note that callbacks are received on a non-ui thread so have to eg use {@link #getActivity()}runOnUiThread(Runnable)} to interact view UI components
     */
    private final DiscoveryEventListener cameraDiscoveryListener = new DiscoveryEventListener() {
        @Override
        public void onCameraFound(Identity identity) {
            ThermalLog.d(TAG, "onCameraFound identity:" + identity);
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    cameraHandler.add(identity);
                    viewAdapter.notifyDataSetChanged();
                }
            });
        }

        @Override
        public void onDiscoveryError(CommunicationInterface communicationInterface, ErrorCode errorCode) {
            ThermalLog.d(TAG, "onDiscoveryError communicationInterface:" + communicationInterface + " errorCode:" + errorCode);
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    stopDiscovery();
                    CameraFragment.this.showMessage.show("onDiscoveryError communicationInterface:" + communicationInterface + " errorCode:" + errorCode);
                }
            });
        }
    };

    /**
     * Camera connecting state listener, keeps track of if the camera is connected or not
     * <p>
     * Note that callbacks are received on a non-ui thread so have to eg use {@link #getActivity().runOnUiThread(Runnable)} to interact view UI components
     */
    private final ConnectionStatusListener connectionStatusListener = new ConnectionStatusListener() {
        @Override
        public void onDisconnected(@Nullable ErrorCode errorCode) {
            ThermalLog.d(TAG, "onDisconnected errorCode:" + errorCode);

            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Log.d(TAG, connectedIdentity + " DISCONNECTED");
                    CameraFragment.this.connectedIdentity = null;
                }
            });
        }
    };

    private final CameraFragment.ShowMessage showMessage = new ShowMessage() {
        @Override
        public void show(String message) {
            Toast.makeText(getActivity().getApplicationContext(), message, Toast.LENGTH_SHORT).show();

        }
    };

    /**
     * Connect to a Camera
     */
    private void connect(Identity identity) {
        cameraHandler.stopDiscovery(discoveryStatusListener);

        if (connectedIdentity != null) {
            ThermalLog.d(TAG, "connect(), in *this* code sample we only support one camera connection at the time");
            showMessage.show("connect(), in *this* code sample we only support one camera connection at the time");
            return;
        }

        if (identity == null) {
            ThermalLog.d(TAG, "connect(), can't connect, no camera available");
            showMessage.show("connect(), can't connect, no camera available");
            return;
        }

        connectedIdentity = identity;
        Log.d(TAG, identity + " AUTHENTICATING & CONNECTING");
        new Thread(() -> {
            Log.d(TAG, identity + " AUTHENTICATING START");

            //Perform authentication against the camera
            try {
                AuthenticationResponse response;
                do {
                    //Calling the camera asking for authentication
                    response = cameraHandler.authenticate(identity, getApplicationName());

                    if (response.authenticationStatus == AuthenticationResponse.AuthenticationStatus.APPROVED) {
                        Log.d(TAG, identity + " AUTHENTICATING DONE");
                    } else {
                        Log.d(TAG, identity + " WAITING FOR AUTHENTICATING");
                        ThermalLog.d(TAG, "Authentication status: " + response.authenticationStatus.name());
                        Thread.sleep(1 * 1000);
                    }
                } while (response.authenticationStatus != AuthenticationResponse.AuthenticationStatus.APPROVED);
            } catch (IOException | InterruptedException e) {
                ThermalLog.d(TAG, "Authentication failed: " + e);
                Log.d(TAG, identity + " DISCONNECTED error:" + e);
                return;
            }
            Log.d(TAG, identity + " CONNECTING");
            //Connect to the camera
            try {
                cameraHandler.connect(identity, connectionStatusListener);
                getActivity().runOnUiThread(() -> {
                    Log.d(TAG, identity + " CONNECTED");
                    try {
                        showMessage.show("You are successfully connected to " + identity.deviceId + "!");
                        buttonInfo.setVisibility(View.VISIBLE);
                        buttonAddImage.setVisibility(View.VISIBLE);
                        //cameraHandler.startImport(importInformation);
                        //mudei a excecao de baixo e a linha de cima é para fazer o import de imagens !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                    } catch (Exception e) {
                        ThermalLog.d(TAG, "startImport(), failed with the following exception:" + e);
                        showMessage.show("Failed to import images from Camera");
                    }
                });
            } catch (IOException e) {
                ThermalLog.d(TAG, "Connection failed: " + e);
                Log.d(TAG, identity + " DISCONNECTED");
            }
        }).start();
        //after connection, to get some data to show in InfoFragment
    }

    private String getApplicationName() {
        //This is a work-around for a bug in some cameras, need a "persistent" name
        String applicationName = CameraAuthName.getApplicationName(getActivity());
        ThermalLog.d(TAG, "getApplicationName:" + applicationName);
        return applicationName;
    }

    /**
     * Disconnect from a camera
     */
    private void disconnect() {
        ThermalLog.d(TAG, "disconnect() called with: connectedIdentity = [" + connectedIdentity + "]");
        Log.d(TAG, connectedIdentity + " DISCONNECTED");
        connectedIdentity = null;
        new Thread(() -> {
            cameraHandler.disconnect();
        }).start();
    }

    /**
     * Click listener to handle selection in List view that shows network cameras
     */
    private final ListAdapter.UIAdapterClickListener UIAdapterClickListener = new ListAdapter.UIAdapterClickListener() {
        @Override
        public void itemSelected(Identity identity) {
            connect(identity);
            Log.e(TAG, identity + "was selected");
        }
    };

}