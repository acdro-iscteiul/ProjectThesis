package com.example.flirnavigation;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;


public class AddPatient_Fragment extends Fragment {
    private EditText editTextUserID;
    private EditText editTextName;
    private EditText editTextAge;
    private EditText editTextSex;
    private Button saveButton;
    private ArrayList<PatientsInfo> listOfPatients = new ArrayList<>();


    public AddPatient_Fragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_add_patient_, container, false);
        editTextUserID = v.findViewById(R.id.editTextUserID);
        editTextName = v.findViewById(R.id.editTextName);
        editTextAge = v.findViewById(R.id.editTextAge);
        editTextSex = v.findViewById(R.id.editTextSex);
        saveButton = v.findViewById(R.id.saveButton);

        // Write a message to the database
        FirebaseDatabase mDatabase = FirebaseDatabase.getInstance();
        DatabaseReference mReferenceDB = mDatabase.getReference();



        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String patientID = editTextUserID.getText().toString();
                String patientName = editTextName.getText().toString();
                int patientAge = Integer.parseInt(editTextAge.getText().toString());
                String patientSex =  editTextSex.getText().toString();

                PatientsInfo newPatient = new PatientsInfo(patientAge, patientID, patientName, patientSex);
                listOfPatients.add(newPatient);
                Log.e("TAG", "new patient is: " + newPatient.toString());
                mReferenceDB.child("patients").child(patientID).setValue(newPatient);

                Toast.makeText(getActivity().getApplicationContext(), "Patient was added successfully!", Toast.LENGTH_SHORT).show();
            }
        });

        return v;
    }
}