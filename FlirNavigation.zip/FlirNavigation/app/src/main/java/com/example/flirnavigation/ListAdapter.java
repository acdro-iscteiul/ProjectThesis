package com.example.flirnavigation;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.flir.thermalsdk.live.Identity;

import java.util.List;

public class ListAdapter extends RecyclerView.Adapter<ListAdapter.MyViewHolder> {
    private final UIAdapterClickListener clickListener;
    private List<Identity> dataset;

    public interface UIAdapterClickListener {
        void itemSelected(Identity identity);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView textView;
        public Identity identity;

        public MyViewHolder(View v) {
            super(v);
            TextView textView = v.findViewById(R.id.adapter_textView);
            v.setOnClickListener(this);
            this.textView = textView;
        }

        @Override
        public void onClick(View v) {
            Identity identity = dataset.get(getAdapterPosition());
            clickListener.itemSelected(identity);
        }
    }

    public ListAdapter(List<Identity> dataset, UIAdapterClickListener clickListener) {
        this.dataset = dataset;
        this.clickListener = clickListener;
    }

    @Override
    public ListAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.my_text_view, parent, false);
        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Identity identity = dataset.get(position);
        String deviceId = String.format("%s \n %s", identity.deviceId, identity.ipSettings.ipAddress);
        holder.textView.setText(deviceId);
        holder.identity = identity;
    }

    @Override
    public int getItemCount() {
        return dataset.size();
    }
}
