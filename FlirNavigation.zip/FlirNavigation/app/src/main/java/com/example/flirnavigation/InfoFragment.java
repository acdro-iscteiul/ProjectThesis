package com.example.flirnavigation;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.VisibleForTesting;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentResultListener;

import android.support.test.espresso.idling.CountingIdlingResource;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.flir.thermalsdk.ErrorCode;
import com.flir.thermalsdk.androidsdk.ThermalSdkAndroid;
import com.flir.thermalsdk.image.palettes.Palette;
import com.flir.thermalsdk.live.remote.Battery;
import com.flir.thermalsdk.live.remote.Calibration;
import com.flir.thermalsdk.live.remote.OnReceived;
import com.flir.thermalsdk.live.remote.OnRemoteError;
import com.flir.thermalsdk.live.remote.PaletteController;
import com.flir.thermalsdk.log.ThermalLog;


public class InfoFragment extends Fragment {

    private static final String TAG = "InfoFragment";
    private TextView textBattery;
    private TextView textBatteryState;
    private TextView textPalette;
    private TextView textNuc;
    private CameraHandler cameraResult;

    private final CountingIdlingResource batteryPercentageIdlingResource = new CountingIdlingResource("BATTERY_PERCENTAGE_SUBSCRIPTION");
    private final CountingIdlingResource paletteIdlingResource = new CountingIdlingResource("UPDATE_PALETTE_ASYNC");
    private final CountingIdlingResource calibrationIdlingResource = new CountingIdlingResource("CALIBRATION_SUBSCRIPTION");


    public InfoFragment() {
        // Required empty public constructor
    }

    /**
     * Show message on the screen
     */
    public interface ShowMessage {
        void show(String message);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_info, container, false);
        ThermalSdkAndroid.init(getActivity().getApplicationContext());

        TextView textID = v.findViewById(R.id.textID);
        TextView textCamType = v.findViewById(R.id.textCamType);
        TextView textIP = v.findViewById(R.id.textIP);
        textBattery = v.findViewById(R.id.textBattery);
        textBatteryState = v.findViewById(R.id.textBatteryState);
        textPalette = v.findViewById(R.id.textPalette);
        textNuc = v.findViewById(R.id.textNuc);

        //args from CameraFragment
        try {
            cameraResult = InfoFragmentArgs.fromBundle(getArguments()).getCameraInstance();
            textID.setText("Camera ID: " + cameraResult.foundCameraIdentities.get(0).deviceId);
            textCamType.setText("Camera Type: " + cameraResult.foundCameraIdentities.get(0).cameraType.toString());
            textIP.setText("Camera IP: " + cameraResult.foundCameraIdentities.get(0).ipSettings.ipAddress);

            setBatteryInfo();

            setPaletteInfo();

            setNUC();

        } catch (IllegalArgumentException e) {
            showMessage.show("Connect to the camera first!");
        }
        return v;
    }

    public void setBatteryInfo() {
        Battery batteryController = cameraResult.getRemoteControl().getBattery();
        if (batteryController == null) {
            showMessage.show("Battery is not supported by the connected camera");
            return;
        }

        // Set a subscription for the battery's percentage changes
        batteryPercentageIdlingResource.increment();
        batteryController.percentage().subscribe(new OnReceived<Integer>() {
            @Override
            public void onReceived(Integer percentage) {
                Log.e(TAG, percentage + " was sent trough a bundle");
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        textBattery.setText("Battery Level: " + percentage);
                    }
                });

                if (!batteryPercentageIdlingResource.isIdleNow()) {
                    batteryPercentageIdlingResource.decrement();
                }
            }
        });

        // Get asynchronously the battery's charging state
        batteryPercentageIdlingResource.increment();
        batteryController.chargingState().get(new OnReceived<Battery.ChargingState>() {
            @Override
            public void onReceived(Battery.ChargingState chargingState) {
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        textBatteryState.setText("Battery State: " + chargingState.toString());
                    }
                });
                batteryPercentageIdlingResource.decrement();
            }
        }, new OnRemoteError() {
            @Override
            public void onRemoteError(ErrorCode errorCode) {
                batteryPercentageIdlingResource.decrement();
                String errorLogMessage = "Error getting the battery's charging state: " + errorCode.getMessage();
                showMessage.show(errorLogMessage);
            }
        });
    }

    public void setPaletteInfo() {
        PaletteController paletteController = cameraResult.getRemoteControl().getPaletteController();
        if (paletteController == null) {
            showMessage.show("PaletteController is not supported by the connected camera");
            return;
        }
        // Get synchronously a palette
        paletteIdlingResource.increment();
        try {
            Palette currentPalette = paletteController.currentPalette().getSync();
            //send info to InfoFragment
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    textPalette.setText("Battery State: " + currentPalette.name);
                }
            });
            paletteIdlingResource.decrement();
        } catch (RuntimeException e) {
            String errorLogMessage = "Palettes error: " + e.getMessage();
            ThermalLog.d(TAG, errorLogMessage);
            showMessage.show(errorLogMessage);
        }
    }

    public void setNUC() {
        //camera Calibration
        Calibration calibrationController = cameraResult.getRemoteControl().getCalibration();
        if (calibrationController == null) {
            showMessage.show("Calibration is not supported by the connected camera");
            return;
        }

        // Set a subscription for the calibration's NUC state changes
        calibrationIdlingResource.increment();
        calibrationController.nucState().subscribe(new OnReceived<Calibration.NucState>() {
            @Override
            public void onReceived(Calibration.NucState nucState) {
                ThermalLog.d(TAG, "NUC State subscription value received: " + nucState.toString());

                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        textNuc.setText("NUC State: " + nucState.toString());
                    }
                });

                if (!calibrationIdlingResource.isIdleNow()) {
                    calibrationIdlingResource.decrement();
                }
            }
        });
    }

    @VisibleForTesting
    public CountingIdlingResource getBatteryPercentageIdlingResource() {
        return batteryPercentageIdlingResource;
    }

    private InfoFragment.ShowMessage showMessage = new InfoFragment.ShowMessage() {
        @Override
        public void show(String message) {
            Toast.makeText(getActivity().getApplicationContext(), message, Toast.LENGTH_SHORT).show();

        }
    };
}