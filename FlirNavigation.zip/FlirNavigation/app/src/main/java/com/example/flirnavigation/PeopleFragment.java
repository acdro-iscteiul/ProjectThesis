package com.example.flirnavigation;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.flir.thermalsdk.live.importing.FileObject;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.NotNull;

import java.util.ArrayList;

public class PeopleFragment extends Fragment {

    private static final String TAG = "PeopleFragment";


    //shit to play with firebase and shit for the fragment that will stay
    private ArrayList<PatientsInfo> patientsInfoList = new ArrayList<>();
    private com.example.flirnavigation.ListAdapterPatients viewAdapterPatients;

    private Button addPatientButton;

    public PeopleFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_people, container, false);
        addPatientButton = v.findViewById(R.id.addPatientButton);


        //firebase shit
        RecyclerView recyclerViewPatients = v.findViewById(R.id.my_recycler_view_patients);
        recyclerViewPatients.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity().getApplicationContext());
        recyclerViewPatients.setLayoutManager(layoutManager);

        DividerItemDecoration mDividerItemDecoration = new DividerItemDecoration(recyclerViewPatients.getContext(),layoutManager.getOrientation());
        recyclerViewPatients.addItemDecoration(mDividerItemDecoration);

        FirebaseDatabase mDatabase = FirebaseDatabase.getInstance();
        DatabaseReference mReferencePatient = mDatabase.getReference("patients");


        mReferencePatient.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                patientsInfoList.clear();
                for (DataSnapshot keyNode : snapshot.getChildren()) {
                    PatientsInfo patientsInfo = keyNode.getValue(PatientsInfo.class);
                    patientsInfoList.add(patientsInfo);
                    Log.e("TAG", "patients list is" + patientsInfoList.toString());

                }
                viewAdapterPatients = new ListAdapterPatients(patientsInfoList, UIAdapterClickListener);
                recyclerViewPatients.setAdapter(viewAdapterPatients);

            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });


        addPatientButton.setOnClickListener(Navigation.createNavigateOnClickListener(R.id.addPatient_Fragment, null));

        return v;
    }



    private final ListAdapterPatients.UIAdapterClickListener UIAdapterClickListener = new ListAdapterPatients.UIAdapterClickListener() {
        @Override
        public void itemSelected(PatientsInfo patientsInfo) {
            Log.e(TAG, "patient selected was " + patientsInfo);
            String nameToSend = patientsInfo.name;
            String idToSend = patientsInfo.id;
            String sexToSend = patientsInfo.sex;
            Integer ageToSend = patientsInfo.age;
            //send args to InfoFragment
            PeopleFragmentDirections.ActionPeopleToPatientProfile actionPeopleToPatientProfile = PeopleFragmentDirections.actionPeopleToPatientProfile(nameToSend, idToSend,sexToSend,ageToSend);
            actionPeopleToPatientProfile.setName(nameToSend);
            actionPeopleToPatientProfile.setID(idToSend);
            actionPeopleToPatientProfile.setSex(sexToSend);
            actionPeopleToPatientProfile.setAge(ageToSend);
            Navigation.findNavController(getView()).navigate(actionPeopleToPatientProfile);
        }
    };
}
