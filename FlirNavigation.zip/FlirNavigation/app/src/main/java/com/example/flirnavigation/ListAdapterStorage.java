package com.example.flirnavigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.flir.thermalsdk.live.importing.FileObject;

import java.util.List;

public class ListAdapterStorage extends RecyclerView.Adapter<ListAdapterStorage.MyViewHolder> {
    private final UIAdapterClickListener clickListener;
    private List<FileObject> dataset;

    public interface UIAdapterClickListener {
        void itemSelected(FileObject fileObject);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView textView;
        public FileObject fileObject;

        public MyViewHolder(View v) {
            super(v);
            TextView textView = v.findViewById(R.id.adapter_textViewStorage);
            v.setOnClickListener(this);
            this.textView = textView;
        }

        @Override
        public void onClick(View v) {
            FileObject fileObject = dataset.get(getAdapterPosition());
            clickListener.itemSelected(fileObject);
        }
    }

    public ListAdapterStorage(List<FileObject> dataset, UIAdapterClickListener clickListener) {
        this.dataset = dataset;
        this.clickListener = clickListener;
    }

    @Override
    public ListAdapterStorage.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.my_text_view_storage, parent, false);
        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        FileObject fileObject = dataset.get(position);
        String deviceId = String.format("%s \n %s", fileObject.name, fileObject.time);
        holder.textView.setText(deviceId);
        holder.fileObject = fileObject;
    }

    @Override
    public int getItemCount() {
        return dataset.size();
    }
}

