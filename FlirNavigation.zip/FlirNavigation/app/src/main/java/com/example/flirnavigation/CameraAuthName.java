package com.example.flirnavigation;


import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

public class CameraAuthName {

    public static final String KEY = "com.samples.networkcamera.Application_ID";
    public static final String BaseName = "FLIRSample";

    /**
     * Return a "persistent" name,
     * the name will deleted if the application is uninstalled but not changed if the application is just re-installed
     *
     * @return a name or empty string
     * */
    public static String getApplicationName(Activity activity) {
        SharedPreferences sharedPref = activity.getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();

        String name;
        if (sharedPref.contains(KEY)) {
            //return the name from storage
            name = sharedPref.getString(KEY, "");
        } else {
            //write the name to storage and return it
            name = BaseName + (System.currentTimeMillis() % 10000);
            editor.putString(KEY, name);
            editor.commit();
        }
        return name;
    }
}
