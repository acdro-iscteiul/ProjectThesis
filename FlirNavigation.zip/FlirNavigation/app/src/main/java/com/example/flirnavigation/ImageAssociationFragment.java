package com.example.flirnavigation;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.UiThread;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentResultListener;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.flir.thermalsdk.ErrorCode;
import com.flir.thermalsdk.androidsdk.image.BitmapAndroid;
import com.flir.thermalsdk.image.ImageFactory;
import com.flir.thermalsdk.image.JavaImageBuffer;
import com.flir.thermalsdk.image.ThermalImageFile;
import com.flir.thermalsdk.image.fusion.FusionMode;
import com.flir.thermalsdk.live.importing.FileObject;
import com.flir.thermalsdk.live.remote.LocalDateTime;
import com.flir.thermalsdk.log.ThermalLog;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.NotNull;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class ImageAssociationFragment extends Fragment implements AdapterView.OnItemSelectedListener {


    private static final String TAG = "ImageAssFragment";

    private ImageView lastStoredImageView;
    private Bitmap testeBitmap;
    private com.example.flirnavigation.ListAdapterStorage viewAdapterStorage;
    private CameraHandler cameraResult;
    private Spinner spinnerOfPatients;
    private ArrayList<String> spinnerList;
    private ArrayAdapter<String> arrayAdapter;
    private Button associateButton;
    private Uri filePath;
    private String stringSpinner;
    private String nameOfFile;
    private LocalDateTime timeOfFile;
    private TextView legendImageView;

    // instance for firebase storage and StorageReference
    private FirebaseStorage storage;
    private StorageReference storageReference;
    private StorageReference imageRef;

    public ImageAssociationFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_image_association, container, false);
        spinnerList = new ArrayList<>();
        TextView textView2 = v.findViewById(R.id.textView2);
        lastStoredImageView = v.findViewById(R.id.imageViewBitMap);
        spinnerOfPatients = v.findViewById(R.id.spinnerOfPatients);
        associateButton = v.findViewById(R.id.associateButton);
        legendImageView = v.findViewById(R.id.legendImageView);

        FirebaseDatabase mDatabase = FirebaseDatabase.getInstance();
        DatabaseReference mReferencePatient = mDatabase.getReference("patients");
        DatabaseReference mReferenceImages = mDatabase.getReference("images");
        // get the Firebase  storage reference
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();


        mReferencePatient.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                spinnerList.clear();
                for (DataSnapshot keyNode : snapshot.getChildren()) {
                    PatientsInfo patientsInfo = keyNode.getValue(PatientsInfo.class);
                    spinnerList.add(patientsInfo.toString());
                    Log.e("TAG", "patients list is" + spinnerList.toString());

                }
            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });
        //weird bug !!!!!!!!!!!!!!!!!!!!!!
        spinnerList.add("Select a patient");

        arrayAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, spinnerList);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        arrayAdapter.notifyDataSetChanged();
        spinnerOfPatients.setAdapter(arrayAdapter);
        spinnerOfPatients.setOnItemSelectedListener(this);


        //args from CameraFragment
        cameraResult = ImageAssociationFragmentArgs.fromBundle(getArguments()).getCameraInstance();
        Log.e(TAG, "camera received from bundle navigation is " + cameraResult);

        //Setup the storage list
        RecyclerView recyclerView = v.findViewById(R.id.my_recycler_view_storage);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity().getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        try {
            viewAdapterStorage = new ListAdapterStorage(cameraResult.getCameraStorageList(), UIAdapterClickListener);
        } catch (IOException e) {
            e.printStackTrace();
        }
        recyclerView.setAdapter(viewAdapterStorage);


        lastStoredImageView.setOnClickListener(v1 -> {
            //BitmapDrawable bitmapDrawable = (BitmapDrawable) lastStoredImageView.getDrawable();
            //Bitmap bitmap = bitmapDrawable.getBitmap();
            shareImageandText(testeBitmap);
            //write in db
        });


        associateButton.setOnClickListener(v12 -> {

            try {

                //ImageAssociationFragmentDirections.ActionImageAssociationFragmentToPeopleFragment actionImageAssociationFragmentToPeopleFragment = ImageAssociationFragmentDirections.actionImageAssociationFragmentToPeopleFragment(timeOfFile.day);
                //actionImageAssociationFragmentToPeopleFragment.setImageDate(timeOfFile.day);
                //Navigation.findNavController(v).navigate(actionImageAssociationFragmentToPeopleFragment);

                // Get the data from an ImageView as bytes
                lastStoredImageView.setDrawingCacheEnabled(true);
                lastStoredImageView.buildDrawingCache();
                Bitmap bitmap = ((BitmapDrawable) lastStoredImageView.getDrawable()).getBitmap();
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] data = baos.toByteArray();

                UploadTask uploadTask = imageRef.putBytes(data);
                uploadTask.addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        // Handle unsuccessful uploads
                    }
                }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        // taskSnapshot.getMetadata() contains file metadata such as size, content-type, etc.
                        showMessage.show(nameOfFile + " associated successfully to " + stringSpinner);

                        Task<Uri> urlTask = uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                            @Override
                            public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) {
                                if (!task.isSuccessful()) {
                                    Log.i("problem", task.getException().toString());
                                }

                                return imageRef.getDownloadUrl();
                            }
                        }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                            @Override
                            public void onComplete(@NonNull Task<Uri> task) {
                                if (task.isSuccessful()) {
                                    Uri downloadUri = task.getResult();


                                    mReferencePatient.child(stringSpinner).child(stringSpinner + "_" + nameOfFile.substring(0,8)).setValue(downloadUri.toString());
                                    mReferencePatient.child(stringSpinner).child("imageDates").child(stringSpinner + "_" + nameOfFile.substring(0,8) + "_date").setValue(timeOfFile.toString());
                                    mReferenceImages. child(stringSpinner + "_" + nameOfFile.substring(0,8)).setValue(stringSpinner + "_" + nameOfFile.substring(0,8)+ ".jpg");

                                    Log.e("seeThisUri", downloadUri.toString());// This is the one you should store


                                } else {
                                    Log.e("wentWrong","downloadUri failure");
                                }
                            }


                        });
                    }
                });
            } catch (NullPointerException e) {
                showMessage.show("Select an image and user to save");
                e.printStackTrace();
            }

        });


        return v;
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        stringSpinner = parent.getItemAtPosition(position).toString();
        // Showing selected spinner item
        //set as selected item.
        //spinnerOfPatients.setSelection(position);
        showMessage.show(stringSpinner + " is selected");
        imageRef = storageReference.child(stringSpinner).child(stringSpinner + "_" + nameOfFile);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }


    /**
     * Click listener to handle selection in List view that shows image files (storage)
     */
    private final ListAdapterStorage.UIAdapterClickListener UIAdapterClickListener = new ListAdapterStorage.UIAdapterClickListener() {
        @Override
        public void itemSelected(FileObject fileObject) {
            uploadImage(fileObject);
            nameOfFile = fileObject.name;
            timeOfFile = fileObject.time;
            String dateInStringFormat = timeOfFile.toString();
            legendImageView.setVisibility(View.VISIBLE);
            legendImageView.setText(nameOfFile);
            Log.e(TAG, fileObject.name + " was selected");

        }
    };

    @UiThread
    private void uploadImage(FileObject fileObject) {
        try {
            cameraResult.startImport(importInformation, fileObject);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void shareImageandText(Bitmap bitmap) {
        filePath = getImageToShare(bitmap);
        Intent intent = new Intent(Intent.ACTION_SEND);


        // putting uri of image to be shared
        intent.putExtra(Intent.EXTRA_STREAM, filePath);

        // adding text to share
        //intent.putExtra(Intent.EXTRA_TEXT, "Sharing Image");

        // Add subject Here
        //intent.putExtra(Intent.EXTRA_SUBJECT, "Subject Here");

        // setting type to image
        intent.setType("image/jpg");

        // calling startactivity() to share
        startActivity(Intent.createChooser(intent, "Share Via"));
    }

    // Retrieving the url to share
    private Uri getImageToShare(Bitmap bitmap) {
        File imagefolder = new File(getContext().getCacheDir(), "images");
        Uri uri = null;
        try {
            imagefolder.mkdirs();
            File file = new File(imagefolder, stringSpinner + "_" + nameOfFile.substring(0,8)+ ".jpg");
            FileOutputStream outputStream = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, outputStream);
            outputStream.flush();
            outputStream.close();
            uri = FileProvider.getUriForFile(getContext(), "com.example.flirnavigation", file);
        } catch (Exception e) {
            showMessage.show("" + e.getMessage());
        }
        return uri;
    }

    private CameraFragment.ShowMessage showMessage = new CameraFragment.ShowMessage() {
        @Override
        public void show(String message) {
            Toast.makeText(getActivity().getApplicationContext(), message, Toast.LENGTH_SHORT).show();

        }
    };


    CameraHandler.ImportInformation importInformation = new CameraHandler.ImportInformation() {

        @Override
        public void importedFile(FileObject file, File savedInDir) {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    // showMessage.show("File imported:" + file + "\n saved in dir:" + savedInDir.getAbsolutePath());
                    File fullFileName = new File(savedInDir, file.name);
                    displayFile(fullFileName);
                }
            });
        }

        @UiThread
        private void displayFile(File file) {
            //open the file as a normal image
            Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
            testeBitmap = bitmap;
            lastStoredImageView.setImageBitmap(testeBitmap);
            //open the file as a ThermalImage
            //ThermalImageFile irImageFile = openThermalImage(file.getAbsolutePath());

            //get a IR image from ThermalImage
            //displayIrImage(irImageFile, lastStoredImageView);
        }

        /**
         * Open a thermal Image
         */
        private ThermalImageFile openThermalImage(String absoluteFilePath) {
            ThermalImageFile thermalImageFile = null;
            try {
                thermalImageFile = (ThermalImageFile) ImageFactory.createImage(absoluteFilePath);
            } catch (IOException e) {
                ThermalLog.e("TAG", "openThermalImage(), failed to open IR file, exception:" + e);
            }
            return thermalImageFile;
        }

        /**
         * Extract IR image from a ThermalImage and display
         */
        @UiThread
        private void displayIrImage(ThermalImageFile imageFile, ImageView irImage) {
            try {
                imageFile.getFusion().setFusionMode(FusionMode.THERMAL_ONLY);
                JavaImageBuffer image = imageFile.getImage();
                BitmapAndroid irBitmap = BitmapAndroid.createBitmap(image);
                irImage.setImageBitmap(irBitmap.getBitMap());
            } catch (NullPointerException e) {
                showMessage.show("chose a thermal image!");
                Log.e("TAG", "The image chosen was not thermal, please choose another one.");
            }

        }

        @Override
        public void importedFileError(FileObject file, ErrorCode errorCode) {
            showMessage.show("importedFileError() called with: file = [" + file + "], errorCode = [" + errorCode + "]");
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    showMessage.show("File imported failed" + file + " with error" + errorCode);
                }
            });

        }
    };

}