package com.example.flirnavigation;


import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.flir.thermalsdk.live.Identity;
import com.google.common.base.Strings;
import com.google.firebase.database.annotations.NotNull;
import com.squareup.picasso.Picasso;

import java.util.List;


public class ImageFirebaseAdapter extends RecyclerView.Adapter<ImageFirebaseAdapter.MyViewHolder> {
    private List<String> dataset;
    private Context mContext;



    public class MyViewHolder extends RecyclerView.ViewHolder {
        public ImageView imageView;

        public MyViewHolder(View v) {
            super(v);
            ImageView imageView = v.findViewById(R.id.image_view_firebase);
            this.imageView = imageView;
        }
    }

    public ImageFirebaseAdapter(List<String> dataset, Context context) {
        this.dataset = dataset;
        this.mContext = context;
    }

    @Override
    public ImageFirebaseAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.image_item, parent, false);
        ImageFirebaseAdapter.MyViewHolder vh = new ImageFirebaseAdapter.MyViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull ImageFirebaseAdapter.MyViewHolder holder, int position) {
        String uploadCurrent = dataset.get(position);
        Log.e("TAG", "current upload to recycler view " + uploadCurrent );

        Picasso.with(mContext)
                .load(uploadCurrent)
                .placeholder(R.drawable.ic_processimage)
                .fit()
                .into(holder.imageView);
    }



    @Override
    public int getItemCount() {
        return dataset.size();
    }

}