package com.example.flirnavigation;


import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.flir.thermalsdk.live.Identity;
import com.google.common.base.Strings;
import com.google.firebase.database.annotations.NotNull;
import com.squareup.picasso.Picasso;

import java.util.List;


public class ImageFirebaseAdapter extends RecyclerView.Adapter<ImageFirebaseAdapter.MyViewHolder> {
    private List<String> dataset;
    private List<String> listOfDates;
    private Context mContext;



    public class MyViewHolder extends RecyclerView.ViewHolder {
        public ImageView imageView;
        public TextView imageDateTextView;

        public MyViewHolder(View v) {
            super(v);
            ImageView imageView = v.findViewById(R.id.image_view_firebase);
            TextView imageDateTextView = v.findViewById(R.id.imageDateTextView);
            this.imageView = imageView;
            this.imageDateTextView = imageDateTextView;
        }
    }

    public ImageFirebaseAdapter(List<String> dataset, List<String> listOfDates, Context context) {
        this.dataset = dataset;
        this.listOfDates = listOfDates;
        this.mContext = context;
    }

    @Override
    public ImageFirebaseAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.image_item, parent, false);
        ImageFirebaseAdapter.MyViewHolder vh = new ImageFirebaseAdapter.MyViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull ImageFirebaseAdapter.MyViewHolder holder, int position) {
        String uploadCurrent = dataset.get(position);
        String dateUpload = listOfDates.get(position);
        Log.e("TAG", "current upload to recycler view " + uploadCurrent );

        holder.imageDateTextView.setText(dateUpload);

        Picasso.with(mContext)
                .load(uploadCurrent)
                .placeholder(R.drawable.ic_processimage)
                .fit()
                .into(holder.imageView);


    }



    @Override
    public int getItemCount() {
        return dataset.size();
    }

}